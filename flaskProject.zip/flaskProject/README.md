Hello this is the instructions and guide to my url shortner
code! <br />

For this project I worked about 2 and a half hours almost. I used a couple external sources to get the html
code to work. I used a bootstrap link I found online to create the website and edited it from there. 
I used Pycharm as my ide to make this code and I used python flask framework. <br />

To run this project, just run the app.py file <br />

For the shortening technique, I used a random letter generator that generated random letters using both uppercase
and lowercase letters. On my main home page you just insert a website but the input requires you to
start the url with https:// or else it will not allow it. <br />

For the database I used a sqllite database but used flask SQLALchemy in the code. This database stored the long urls
and the shortened versions of those. I used this database to keep track of the urls. <br />

I was not able to create the url expander portion of it, but I do have code commented out that I can discuss on later on
what my thought process was and how I was going to finish it. <br />

Overall this was a very fun project and I hope to discuss it further and see what else I can improve on from it!