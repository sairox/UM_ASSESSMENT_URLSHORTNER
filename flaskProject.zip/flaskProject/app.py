from flask import Flask, render_template, request, redirect, url_for
from flask_sqlalchemy import SQLAlchemy
import random
import string

app = Flask(__name__)
app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///urlDB.db'
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False

# creating the database model
db = SQLAlchemy(app)


class UrlDB(db.Model):
    # the columns for the database
    # the first one is the id which is the primary key and how we can retrieve the row/data
    id = db.Column("id_", db.Integer, primary_key=True)
    long_url = db.Column("long_url", db.String())
    # cant have more than a size of 5 for this column
    short_url = db.Column("short_url", db.String(9))

    def __init__(self, long_url, short_url):
        self.long_url = long_url
        self.short_url = short_url


# before we make any request this method will run and create all columns defined in the model above
@app.before_first_request
def create_table():
    db.create_all()


# function to create the shortened url
def shorten_url():
    upper_lowercase_letters = string.ascii_lowercase + string.ascii_uppercase

    random_letters = random.choices(upper_lowercase_letters, k=5)
    # converts the list of random letters into a string
    random_letters = "".join(random_letters)
    return random_letters


@app.route('/', methods=['POST', 'GET'])
def home_page():
    # for short url

    # if it is a post method, then we take the url we receive on the page and store it in a variable,
    # we then return that variable
    if request.method == 'POST':
        # receive long url
        if request.form["URL"]:
            url_received = request.form["URL"]

            # check to see if that url exists in the database
            existing_url = UrlDB.query.filter_by(long_url=url_received).first()
            if existing_url:
                # return short url if it exists, takes you to the rerouted page
                return redirect(url_for("display_short_url", url=existing_url.short_url))
            else:
                # create the short url
                short_url = shorten_url()
                new_url = UrlDB(url_received, short_url)

                # adding the short url to the database
                db.session.add(new_url)
                db.session.commit()
                # returns the new url in the rerouted page
                return redirect(url_for("display_short_url", url=short_url))

            # To discuss later on
#        elif request.form["LONG_URL"]:
#            url_received = request.form["LONG_URL"]
#            existing_url = UrlDB.query.filter_by(short_url=url_received).first()
#
#            if existing_url:
#                return redirect(url_for("display_long_url", url=existing_url.long_url))
#            else:
#                return f'<h1> Url does not exist'

    # otherwise we just display that home page till the user submits something
    else:
        return render_template("home.html")

    # for long url


# the route to show the shortened url
@app.route('/display/<url>')
def display_short_url(url):
    return render_template('shortenedurl.html', short_url_display=url)

# to discuss later on
# @app.route('/display/<long_url>)')
# def display_long_url(url):
#     return render_template('longurl.html', long_url_display=url)


if __name__ == '__main__':
    # debug is set to true to find out what certain problems are if they occur
    app.run(port=5000, debug=True)
